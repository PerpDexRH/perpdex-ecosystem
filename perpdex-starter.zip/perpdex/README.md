# PerpDex

### One position for the whole thesis.

PerpDex is an onchain perpetual protocol for trading fixed-weight market indexes.

Bundle multiple assets into one index, then express the whole market thesis with a single long or short perpetual position.

## Example

```text
TECH100
NVDA 25%
AAPL 20%
MSFT 20%
AMZN 20%
GOOGL 15%
```

Trade:

```text
LONG TECH100
```

## Core formula

```text
Index Price = Σ(asset price × weight)
```

Weights use basis points:

```text
10000 = 100%
```

## Repository

```text
src/
  PerpDex.sol
  IndexRegistry.sol
  IndexOracle.sol
  MarginVault.sol
  FundingRate.sol
  interfaces/
script/
  Deploy.s.sol
  DeployIndex.s.sol
test/
  IndexRegistry.t.sol
  IndexOracle.t.sol
  PerpDex.t.sol
```

## Robinhood Chain

Mainnet:
- Chain ID: 4663
- Currency: ETH
- RPC: https://rpc.mainnet.chain.robinhood.com

Testnet:
- Chain ID: 46630
- Currency: ETH
- RPC: https://rpc.testnet.chain.robinhood.com

## Development

```bash
forge build
forge test
```

Create `.env` from `.env.example`, then deploy:

```bash
forge script script/Deploy.s.sol   --rpc-url $RH_TESTNET_RPC_URL   --private-key $PRIVATE_KEY   --broadcast
```

## Status

Experimental MVP. The included contracts are a starting point and are not production-ready. Production deployment requires robust oracle validation, collateral accounting, funding, liquidation, access control, reentrancy protection, economic testing, and an independent audit.

## License

MIT
