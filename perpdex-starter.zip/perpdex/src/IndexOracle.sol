// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./IndexRegistry.sol";
import "./interfaces/IPriceOracle.sol";
import "./interfaces/IIndexOracle.sol";

contract IndexOracle is IIndexOracle {
    IndexRegistry public immutable registry;
    IPriceOracle public priceOracle;

    constructor(address registry_, address priceOracle_) {
        registry = IndexRegistry(registry_);
        priceOracle = IPriceOracle(priceOracle_);
    }

    function setPriceOracle(address priceOracle_) external {
        // MVP placeholder. Add Ownable/timelock before production.
        priceOracle = IPriceOracle(priceOracle_);
    }

    function getIndexPrice(uint256 indexId)
        public
        view
        override
        returns (uint256)
    {
        require(registry.isActive(indexId), "inactive index");

        IndexRegistry.Component[] memory components =
            registry.getComponents(indexId);

        uint256 totalWeight;
        uint256 weightedPrice;

        for (uint256 i = 0; i < components.length; i++) {
            uint256 p = priceOracle.getPrice(components[i].asset);
            weightedPrice += p * components[i].weightBps;
            totalWeight += components[i].weightBps;
        }

        require(totalWeight == 10_000, "weights != 100%");
        return weightedPrice / 10_000;
    }
}
