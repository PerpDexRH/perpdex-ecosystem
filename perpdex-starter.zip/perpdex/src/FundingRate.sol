// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract FundingRate {
    int256 public fundingRateBps;

    event FundingRateUpdated(int256 rateBps);

    function setFundingRate(int256 rateBps) external {
        // MVP placeholder. Add access control and rate bounds before production.
        require(rateBps > -1000 && rateBps < 1000, "rate out of bounds");
        fundingRateBps = rateBps;
        emit FundingRateUpdated(rateBps);
    }
}
