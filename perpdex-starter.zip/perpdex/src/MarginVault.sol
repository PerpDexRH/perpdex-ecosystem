// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract MarginVault {
    mapping(address => uint256) public marginBalance;

    event Deposited(address indexed trader, uint256 amount);
    event Withdrawn(address indexed trader, uint256 amount);

    // MVP accounting only. Connect to an ERC20 collateral token in production.
    function deposit() external payable {
        require(msg.value > 0, "zero deposit");
        marginBalance[msg.sender] += msg.value;
        emit Deposited(msg.sender, msg.value);
    }

    function withdraw(uint256 amount) external {
        require(amount <= marginBalance[msg.sender], "insufficient margin");
        marginBalance[msg.sender] -= amount;
        payable(msg.sender).transfer(amount);
        emit Withdrawn(msg.sender, amount);
    }
}
