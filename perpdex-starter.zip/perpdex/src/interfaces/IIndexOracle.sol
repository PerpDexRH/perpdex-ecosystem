// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IIndexOracle {
    function getIndexPrice(uint256 indexId) external view returns (uint256);
}
