// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract IndexRegistry {
    uint256 public constant BPS = 10_000;

    struct Component {
        address asset;
        uint256 weightBps;
    }

    struct IndexData {
        string name;
        bool active;
        Component[] components;
    }

    uint256 public nextIndexId;
    mapping(uint256 => IndexData) private indexes;

    event IndexCreated(uint256 indexed indexId, string name);
    event ComponentAdded(uint256 indexed indexId, address indexed asset, uint256 weightBps);
    event IndexStatusChanged(uint256 indexed indexId, bool active);

    function createIndex(string calldata name) external returns (uint256 indexId) {
        indexId = nextIndexId++;
        indexes[indexId].name = name;
        indexes[indexId].active = true;
        emit IndexCreated(indexId, name);
    }

    function addComponent(
        uint256 indexId,
        address asset,
        uint256 weightBps
    ) external {
        require(indexId < nextIndexId, "unknown index");
        require(indexes[indexId].active, "inactive index");
        require(asset != address(0), "invalid asset");
        require(weightBps > 0, "invalid weight");

        indexes[indexId].components.push(
            Component({asset: asset, weightBps: weightBps})
        );

        emit ComponentAdded(indexId, asset, weightBps);
    }

    function setActive(uint256 indexId, bool active) external {
        require(indexId < nextIndexId, "unknown index");
        indexes[indexId].active = active;
        emit IndexStatusChanged(indexId, active);
    }

    function getComponents(uint256 indexId)
        external
        view
        returns (Component[] memory)
    {
        return indexes[indexId].components;
    }

    function getIndexName(uint256 indexId)
        external
        view
        returns (string memory)
    {
        return indexes[indexId].name;
    }

    function isActive(uint256 indexId) external view returns (bool) {
        return indexes[indexId].active;
    }
}
