// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./interfaces/IIndexOracle.sol";

contract PerpDex {
    struct Position {
        address trader;
        uint256 indexId;
        int256 notional;
        uint256 entryPrice;
        uint256 margin;
        bool open;
    }

    uint256 public nextPositionId;
    IIndexOracle public immutable oracle;

    mapping(uint256 => Position) public positions;

    event PositionOpened(
        uint256 indexed positionId,
        address indexed trader,
        uint256 indexed indexId,
        int256 notional,
        uint256 entryPrice,
        uint256 margin
    );

    event PositionClosed(
        uint256 indexed positionId,
        uint256 exitPrice,
        int256 pnl
    );

    constructor(address oracle_) {
        oracle = IIndexOracle(oracle_);
    }

    function openPosition(
        uint256 indexId,
        int256 notional,
        uint256 margin
    ) external returns (uint256 positionId) {
        require(notional != 0, "zero notional");
        require(margin > 0, "zero margin");

        uint256 price = oracle.getIndexPrice(indexId);
        positionId = nextPositionId++;

        positions[positionId] = Position({
            trader: msg.sender,
            indexId: indexId,
            notional: notional,
            entryPrice: price,
            margin: margin,
            open: true
        });

        emit PositionOpened(
            positionId,
            msg.sender,
            indexId,
            notional,
            price,
            margin
        );
    }

    function unrealizedPnl(uint256 positionId)
        public
        view
        returns (int256)
    {
        Position memory p = positions[positionId];
        require(p.open, "position closed");

        uint256 currentPrice = oracle.getIndexPrice(p.indexId);

        int256 priceDelta = int256(currentPrice) - int256(p.entryPrice);

        // Long notional > 0; short notional < 0.
        return (p.notional * priceDelta) / int256(p.entryPrice);
    }
}
