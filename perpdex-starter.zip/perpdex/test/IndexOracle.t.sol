// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/IndexRegistry.sol";
import "../src/IndexOracle.sol";

contract MockPriceOracle {
    mapping(address => uint256) public prices;

    function setPrice(address asset, uint256 price) external {
        prices[asset] = price;
    }

    function getPrice(address asset) external view returns (uint256) {
        return prices[asset];
    }
}

contract IndexOracleTest is Test {
    IndexRegistry registry;
    MockPriceOracle prices;
    IndexOracle oracle;

    address a = address(0x1);
    address b = address(0x2);

    function setUp() public {
        registry = new IndexRegistry();
        prices = new MockPriceOracle();
        oracle = new IndexOracle(address(registry), address(prices));
    }

    function testWeightedIndexPrice() public {
        uint256 id = registry.createIndex("TEST");

        registry.addComponent(id, a, 6000);
        registry.addComponent(id, b, 4000);

        prices.setPrice(a, 1000);
        prices.setPrice(b, 2000);

        assertEq(oracle.getIndexPrice(id), 1400);
    }
}
