// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/IndexRegistry.sol";

contract IndexRegistryTest is Test {
    IndexRegistry registry;
    address asset = address(0x1234);

    function setUp() public {
        registry = new IndexRegistry();
    }

    function testCreateIndex() public {
        uint256 id = registry.createIndex("TECH100");
        assertEq(id, 0);
        assertEq(registry.getIndexName(id), "TECH100");
    }

    function testAddComponent() public {
        uint256 id = registry.createIndex("TECH100");
        registry.addComponent(id, asset, 2500);

        IndexRegistry.Component[] memory c = registry.getComponents(id);
        assertEq(c.length, 1);
        assertEq(c[0].asset, asset);
        assertEq(c[0].weightBps, 2500);
    }
}
