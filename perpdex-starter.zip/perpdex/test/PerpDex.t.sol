// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/IndexRegistry.sol";
import "../src/IndexOracle.sol";
import "../src/PerpDex.sol";

contract MockPerpPriceOracle {
    mapping(address => uint256) public prices;

    function setPrice(address asset, uint256 price) external {
        prices[asset] = price;
    }

    function getPrice(address asset) external view returns (uint256) {
        return prices[asset];
    }
}

contract PerpDexTest is Test {
    IndexRegistry registry;
    MockPerpPriceOracle prices;
    IndexOracle oracle;
    PerpDex perp;

    address asset = address(0x1);

    function setUp() public {
        registry = new IndexRegistry();
        prices = new MockPerpPriceOracle();
        oracle = new IndexOracle(address(registry), address(prices));
        perp = new PerpDex(address(oracle));

        uint256 id = registry.createIndex("TEST");
        registry.addComponent(id, asset, 10000);
        prices.setPrice(asset, 1000);
    }

    function testOpenLong() public {
        uint256 id = 0;

        uint256 positionId = perp.openPosition(id, 5000, 1000);
        assertEq(positionId, 0);

        (address trader, uint256 indexId, int256 notional,,,,) =
            perp.positions(positionId);

        assertEq(trader, address(this));
        assertEq(indexId, id);
        assertEq(notional, 5000);
    }
}
