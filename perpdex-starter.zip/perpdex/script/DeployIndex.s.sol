// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../src/IndexRegistry.sol";

contract DeployIndex is Script {
    function run(address registryAddress)
        external
        returns (uint256 indexId)
    {
        vm.startBroadcast();

        IndexRegistry registry = IndexRegistry(registryAddress);
        indexId = registry.createIndex("TECH100");

        // Replace these placeholder addresses with actual supported assets.
        // registry.addComponent(NVDA, 2500);
        // registry.addComponent(AAPL, 2000);
        // registry.addComponent(MSFT, 2000);
        // registry.addComponent(AMZN, 2000);
        // registry.addComponent(GOOGL, 1500);

        vm.stopBroadcast();
    }
}
