// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../src/IndexRegistry.sol";
import "../src/IndexOracle.sol";
import "../src/PerpDex.sol";
import "../src/MarginVault.sol";
import "../src/FundingRate.sol";

contract Deploy is Script {
    function run()
        external
        returns (
            IndexRegistry registry,
            IndexOracle oracle,
            PerpDex perpDex,
            MarginVault vault,
            FundingRate funding
        )
    {
        vm.startBroadcast();

        // Replace with a real production/test oracle adapter.
        address priceOracle = address(0);

        registry = new IndexRegistry();
        oracle = new IndexOracle(address(registry), priceOracle);
        perpDex = new PerpDex(address(oracle));
        vault = new MarginVault();
        funding = new FundingRate();

        vm.stopBroadcast();
    }
}
